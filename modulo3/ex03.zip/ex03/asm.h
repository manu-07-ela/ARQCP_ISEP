#ifndef ASM_H
#define ASM_H
char str_copy_porto2(void);
#endif